import java.io.Serializable;

class PokerInfo implements Serializable {
    String name;
    public PokerInfo(String name) {
        this.name = name;
    }
    @Override
    public String toString() {
        return "You're mom is gay " + name;
    }
}
