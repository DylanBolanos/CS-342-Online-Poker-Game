import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.layout.TilePane;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

public class homeController {
    @FXML
    TextField portText;
    @FXML
    Button connectBtn;
    @FXML
    BorderPane root;

    Client clientConnection;
    int port;

    public void connectToServer()throws IOException{
        port = Integer.parseInt(portText.getText());
        clientConnection = new Client(port);
        clientConnection.start();
        changeScene();
    }

    public void changeScene() throws IOException{
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML/clientGame.fxml"));
        Parent gameRoot = loader.load();  // Load the FXML content into a new Parent
        gameController controller = loader.getController();
        controller.setInfo(clientConnection);
        //gameRoot.getStylesheets().add("/styles/style1.css");
        root.getScene().setRoot(gameRoot);
    }

    public void test(){
        clientConnection.send((String)"gonna kms");
    }
}
