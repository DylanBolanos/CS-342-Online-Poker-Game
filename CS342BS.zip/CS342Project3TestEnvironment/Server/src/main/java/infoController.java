import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.ListView;
import javafx.scene.layout.TilePane;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

public class infoController {
    @FXML
    ListView<String> serverInfo;
    @FXML
    Button offBtn;

    Server serverConnection;
    public void initializeInfo(Server s){
        serverConnection = s;
        serverConnection.setCallback(data -> {
            Platform.runLater(() -> {
                serverInfo.getItems().add(data.toString());
            });
        });
        System.out.println("I made it here");
    }

    public void test(){

    }
}
