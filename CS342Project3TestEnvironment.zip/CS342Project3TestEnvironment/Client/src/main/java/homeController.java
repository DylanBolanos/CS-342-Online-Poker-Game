import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.ListView;
import javafx.scene.layout.TilePane;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.concurrent.Task;

public class homeController {
    int port;
    boolean enteredPort = false;
    Client clientConnection;
    @FXML
    Button portEnterButton;
    @FXML
    TextField portTextField;
    @FXML
    TextArea homeInfo;

    public void portEnterPressed(){
        port = Integer.parseInt(portTextField.getText());
        enteredPort = true;
        homeInfo.appendText("You entered " + port + " as your desired port number!\n");
    }

    public void tryToConnect(){

			clientConnection = new Client(data -> {
				Platform.runLater(() -> {
                    homeInfo.appendText(data.toString() + '\n');
				});
			});
			clientConnection.start();
    }
}
