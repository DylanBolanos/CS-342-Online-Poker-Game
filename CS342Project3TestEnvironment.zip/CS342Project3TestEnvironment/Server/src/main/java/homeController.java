import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.ListView;
import javafx.scene.layout.TilePane;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.concurrent.Task;

public class homeController {
    @FXML
    ListView<String> listItems;
    @FXML
    Server serverConnection;
    @FXML
    Button ClientCounter;
    @FXML
    public void ServerBtnPressed(){
        serverConnection = new Server(data -> {
            Platform.runLater(() -> {
                listItems.getItems().add(data.toString()); // on callback accept we are running this which is just adding messages to the listItems
            });
        });
        startClientCountUpdate();
    }


    @FXML
    public void startClientCountUpdate() {
        // Create the Task that updates the button with the client count
        Task<Void> updateClientCountTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                while (true) {
                    // Simulate checking the client count (this should be updated with actual logic)
                    // This could be updated based on your server's client count
                    Thread.sleep(1000); // Update every 1 second (simulated delay)

                    // Update the button text with the current client count
                    Platform.runLater(() -> {
                        ClientCounter.setText("Clients Connected: " + (serverConnection.count-1));
                    });
                }
            }
        };

        // Start the task in a new background thread
        new Thread(updateClientCountTask).start();
    }

//            serverConnection = new Server(data -> {
//				Platform.runLater(() -> {
//					listItems.getItems().add(data.toString());
//				});
//			});
}